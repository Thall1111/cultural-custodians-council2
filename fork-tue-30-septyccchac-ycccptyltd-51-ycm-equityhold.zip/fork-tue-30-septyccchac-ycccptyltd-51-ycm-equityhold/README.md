# Fork-tue 30 Sept- YCCCHAC/YCCCPTYLTD (51% YCM [Equity - Hold ] 

A Pen created on CodePen.

Original URL: [https://codepen.io/Tim-Hall-the-builder/pen/zxrBRKL](https://codepen.io/Tim-Hall-the-builder/pen/zxrBRKL).

